import "./App.css";
import { HomePage } from "./components/Home";
import { Routes, Route } from "react-router-dom";
import { DetailsPage } from "./components/detailsPage";

function App() {
  return (
    <div className="App">
      <Routes>
        <Route path={"/"} element={<HomePage />}></Route>
        <Route
          path={"https://fast-reef-22226.herokuapp.com/data/search"}
          element={<DetailsPage />}
        ></Route>
      </Routes>
    </div>
  );
}

export default App;
