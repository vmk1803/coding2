const ADD_DATA = "ADD_DATA";

const SORT_DATA = "SORT_DATA";

export { ADD_DATA, SORT_DATA };
